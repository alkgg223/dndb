package com.eggsteal;

import java.util.UUID;
import net.minecraft.core.component.DataComponents;
import net.minecraft.nbt.CompoundTag;
import net.minecraft.network.chat.Component;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.component.CustomData;

public class Steal {
    public static ItemStack makeEgg(int variant, UUID from) {
        ItemStack s = new ItemStack(EggSteal.EGG_ITEMS.get(variant).get());
        if (from != null) {
            CompoundTag t = new CompoundTag();
            t.putUUID("from", from);
            s.set(DataComponents.CUSTOM_DATA, CustomData.of(t));
        }
        return s;
    }

    public static UUID fromOf(ItemStack s) {
        CustomData cd = s.get(DataComponents.CUSTOM_DATA);
        if (cd == null) return null;
        CompoundTag t = cd.copyTag();
        return t.hasUUID("from") ? t.getUUID("from") : null;
    }

    public static String nameOf(ServerLevel sl, Entity e) {
        Economy.Stats st = Economy.get(sl.getServer()).map.get(e.getUUID());
        return st != null ? st.name : e.getName().getString();
    }

    /** A player takes a creature from someone else's base. */
    public static void playerSteal(CreatureEntity c, ServerPlayer p) {
        ServerLevel sl = (ServerLevel) c.level();
        if (c.hatching()) { p.displayClientMessage(Component.literal("§cStill hatching!"), true); return; }
        UUID from = c.owner();
        int v = c.variant();
        c.discard();
        ItemStack egg = makeEgg(v, from);
        if (!p.getInventory().add(egg)) p.drop(egg, false);
        p.sendSystemMessage(Component.literal("§aYou stole " + Creature.VALUES[v].tag() + "§a! Run home and place the egg in your base before they hit you!"));
        notifyVictim(sl, from, p, v);
    }

    public static void notifyVictim(ServerLevel sl, UUID victim, LivingEntity thief, int variant) {
        String msg = "§c" + nameOf(sl, thief) + " stole your " + Creature.VALUES[variant].tag() + "§c! Hit them with your bat to get it back!";
        ServerPlayer vp = sl.getServer().getPlayerList().getPlayer(victim);
        if (vp != null) { vp.sendSystemMessage(Component.literal(msg)); return; }
        Entity e = sl.getEntity(victim);
        if (e instanceof BotEntity b) b.aggro(thief);
    }

    /** Called whenever a living entity is about to be hurt by another living entity. */
    public static void onHit(LivingEntity target, LivingEntity attacker) {
        UUID aid = attacker.getUUID();
        if (target instanceof Player p) {
            for (int i = 0; i < p.getInventory().getContainerSize(); i++) {
                ItemStack s = p.getInventory().getItem(i);
                if (s.getItem() instanceof EggItem ei && aid.equals(fromOf(s))) {
                    int n = s.getCount();
                    p.getInventory().setItem(i, ItemStack.EMPTY);
                    for (int k = 0; k < n; k++) give(attacker, ei.creature.ordinal());
                }
            }
        } else if (target instanceof BotEntity b && b.carried >= 0 && aid.equals(b.carriedFrom)) {
            int v = b.carried;
            b.carried = -1;
            b.carriedFrom = null;
            b.setTarget(null);
            give(attacker, v);
        }
    }

    public static void give(LivingEntity who, int variant) {
        if (who instanceof ServerPlayer sp) {
            ItemStack egg = makeEgg(variant, null);
            if (!sp.getInventory().add(egg)) sp.drop(egg, false);
            sp.sendSystemMessage(Component.literal("§aYou got your " + Creature.VALUES[variant].tag() + " §aegg back!"));
        } else if (who instanceof BotEntity b) {
            b.receive(variant);
        }
    }
}
