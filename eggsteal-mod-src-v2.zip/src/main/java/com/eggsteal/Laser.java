package com.eggsteal;

import net.minecraft.core.BlockPos;
import net.minecraft.core.particles.DustParticleOptions;
import net.minecraft.server.MinecraftServer;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.sounds.SoundEvents;
import net.minecraft.sounds.SoundSource;
import net.minecraft.world.level.block.Blocks;
import net.minecraft.world.level.block.state.BlockState;
import org.joml.Vector3f;

/** The red laser door: pressing a base's button blocks its entrance for 30 seconds. */
public class Laser {
    public static final int DURATION = 600;      // 30 s
    public static final int COOLDOWN = 1800;     // 90 s after pressing
    static final long[] until = new long[Arena.BASES], cool = new long[Arena.BASES], ended = new long[Arena.BASES];
    static final boolean[] on = new boolean[Arena.BASES];
    static final String[] last = new String[Arena.BASES];

    public static boolean active(int b) { return on[b]; }
    public static long endedAt(int b) { return ended[b]; }
    public static boolean ready(MinecraftServer s, int b) { return !on[b] && s.getTickCount() >= cool[b]; }
    public static int coolSeconds(MinecraftServer s, int b) { return (int) Math.max(0, (cool[b] - s.getTickCount()) / 20); }

    static void fill(ServerLevel sl, int b, boolean laser) {
        BlockState st = (laser ? Blocks.RED_STAINED_GLASS : Blocks.AIR).defaultBlockState();
        BlockPos.MutableBlockPos mp = new BlockPos.MutableBlockPos();
        for (int x = Arena.cx(b) - 1; x <= Arena.cx(b) + 1; x++)
            for (int y = 64; y <= 67; y++) sl.setBlock(mp.set(x, y, Arena.gapZ(b)), st, 3);
    }

    public static void reset(ServerLevel sl, int b) {
        on[b] = false;
        until[b] = 0;
        cool[b] = 0;
        last[b] = null;
        fill(sl, b, false);
    }

    public static boolean press(ServerLevel sl, int b) {
        MinecraftServer s = sl.getServer();
        if (!ready(s, b)) return false;
        long n = s.getTickCount();
        on[b] = true;
        until[b] = n + DURATION;
        cool[b] = n + COOLDOWN;
        fill(sl, b, true);
        sl.playSound(null, Arena.cx(b), 65, Arena.gapZ(b), SoundEvents.BEACON_ACTIVATE, SoundSource.BLOCKS, 2f, 0.8f);
        return true;
    }

    public static void tick(ServerLevel sl) {
        MinecraftServer s = sl.getServer();
        long n = s.getTickCount();
        for (int b = 0; b < Arena.BASES; b++) {
            if (on[b]) {
                if (n >= until[b]) {
                    on[b] = false;
                    ended[b] = n;
                    fill(sl, b, false);
                    sl.playSound(null, Arena.cx(b), 65, Arena.gapZ(b), SoundEvents.BEACON_DEACTIVATE, SoundSource.BLOCKS, 2f, 1f);
                } else if (n % 4 == 0) {
                    sl.sendParticles(new DustParticleOptions(new Vector3f(1f, 0f, 0f), 1.3f), Arena.cx(b) + 0.5, 66, Arena.gapZ(b) + 0.5, 14, 1.4, 1.6, 0.05, 0);
                }
            } else if (n % 100 == 0 && sl.getBlockState(new BlockPos(Arena.cx(b), 65, Arena.gapZ(b))).is(Blocks.RED_STAINED_GLASS)) {
                fill(sl, b, false);
            }
            if (n % 20 == 0) {
                String t = on[b] ? "§c§l⚠ LASER ON §f" + Math.max(0, (until[b] - n) / 20) + "s"
                        : n < cool[b] ? "§7Laser recharging " + ((cool[b] - n) / 20) + "s" : "§aDoor open";
                if (!t.equals(last[b])) {
                    last[b] = t;
                    Hud.setText(s, "es_ls" + b, t);
                }
            }
        }
    }
}
