package com.eggsteal;

import java.util.ArrayList;
import java.util.List;

public enum Creature {
    SLIME_BUN("slime_bun", "Slime Bun", 0, 50, 1, 0x59d96b, 0xd6ffd9),
    CHICK_PUFF("chick_puff", "Chick Puff", 0, 100, 2, 0xffe55c, 0xff9d2e),
    MUSHY("mushy", "Mushy", 0, 200, 4, 0xe0463c, 0xf7ead2),
    PEBBLE_PUP("pebble_pup", "Pebble Pup", 0, 400, 8, 0x9c9c9c, 0x5e5e5e),
    FOX_KIT("fox_kit", "Fox Kit", 1, 800, 16, 0xf07f1d, 0xfff2e0),
    FROG_POP("frog_pop", "Frog Pop", 1, 1500, 30, 0x4cc24c, 0xe8ff9c),
    BAT_MOCHI("bat_mochi", "Bat Mochi", 1, 3000, 60, 0x7a4dbd, 0x3b2266),
    CLOUD_CAT("cloud_cat", "Cloud Cat", 1, 6000, 120, 0xeaf4ff, 0x9fd0ff),
    PANDA_BEAN("panda_bean", "Panda Bean", 2, 12000, 240, 0xf5f5f5, 0x1d1d1d),
    DRAGON_PUP("dragon_pup", "Dragon Pup", 2, 25000, 500, 0xd63a3a, 0xffc247),
    ICE_FOX("ice_fox", "Ice Fox", 2, 50000, 1000, 0xbfe9ff, 0x4aa8ff),
    LAVA_MOLE("lava_mole", "Lava Mole", 3, 100000, 2000, 0x4a3a36, 0xff6a00),
    STAR_BUNNY("star_bunny", "Star Bunny", 3, 250000, 5000, 0xffd1f0, 0xffe44d),
    GHOST_MOTH("ghost_moth", "Ghost Moth", 4, 500000, 10000, 0xdcd6ff, 0x7d6bff),
    CRYSTAL_DEER("crystal_deer", "Crystal Deer", 4, 1000000, 20000, 0xc59a6a, 0x4ff0e0),
    GALAXY_WHALE("galaxy_whale", "Galaxy Whale", 5, 5000000, 100000, 0x2b2f8f, 0xd66bff);

    public static final Creature[] VALUES = values();
    public static final String[] RARITY = {"Common", "Uncommon", "Rare", "Epic", "Legendary", "Mythic"};
    public static final String[] RARITY_COLOR = {"§7", "§a", "§9", "§5", "§6", "§c"};

    public final String id, display;
    public final int rarity;
    public final double price, income;
    public final int main, accent;

    Creature(String id, String display, int rarity, double price, double income, int main, int accent) {
        this.id = id; this.display = display; this.rarity = rarity;
        this.price = price; this.income = income; this.main = main; this.accent = accent;
    }

    public String tag() { return RARITY_COLOR[rarity] + display; }

    public static List<Creature> byRarity(int r) {
        List<Creature> l = new ArrayList<>();
        for (Creature c : VALUES) if (c.rarity == r) l.add(c);
        return l;
    }
}
